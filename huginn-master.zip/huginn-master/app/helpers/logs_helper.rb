module LogsHelper
end
